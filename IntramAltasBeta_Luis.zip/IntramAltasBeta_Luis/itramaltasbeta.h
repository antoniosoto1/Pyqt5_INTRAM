#ifndef ITRAMALTASBETA_H
#define ITRAMALTASBETA_H

#include <QMainWindow>

namespace Ui {
class ItramAltasBeta;
}

class ItramAltasBeta : public QMainWindow
{
    Q_OBJECT

public:
    explicit ItramAltasBeta(QWidget *parent = 0);
    ~ItramAltasBeta();

private:
    Ui::ItramAltasBeta *ui;
};

#endif // ITRAMALTASBETA_H
