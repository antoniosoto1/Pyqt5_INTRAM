# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'itramaltasbeta.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

#self.tipotramite1A_2 = QtWidgets.QComboBox(self.centralWidget)
#self.moreoptions1_2 = QtWidgets.QToolButton(self.centralWidget)

class Ui_ItramAltasBeta(object):

    def AgregaTramite_1( self ) :
        self.moreTramits_2.setGeometry(QtCore.QRect(191, 140, 20, 21))        
        self.Quantity_2.setGeometry(QtCore.QRect(215, 140, 30, 20))
        self.moreTramits_2.setText( "+")

        self.tipotramite1A_2.setGeometry(QtCore.QRect(250, 139, 131, 22))
        self.tipotramite1A_2.addItems('Visa Visa_Canada Pasaporte_Mexicano Pasaporte_Americano Apostille Traduccion SSN'.split())        
        self.tipotramite1A_2.setObjectName("tipotramite1A_2")

  #      self.tipotramite1B.setObjectName("tipotramite1B")

 #       self.tipotramite1B_2.setGeometry(QtCore.QRect(410, 140, 81, 20))
 #       self.tipotramite1B_2.setObjectName("tipotramite1B_2")
        
 #       self.tipotramite1C_2.setGeometry(QtCore.QRect(497, 140, 81, 20))
 #       self.tipotramite1C_2.setObjectName("tipotramite1C_2")

        self.moreoptions1_2.setGeometry(QtCore.QRect(387, 140, 16, 19))
        self.moreoptions1_2.setObjectName("moreoptions1_2")
        self.moreoptions1_2.setText( "...")

    def AgregaOpcion1( self ) :
        alt2gs_ttramite =  self.tipotramite1A.currentText()
        a = 'Eng-Esp Esp=Ing Fr-Esp Esp-Fr'

        self.tipotramite1B.addItems(a.split())
        self.tipotramite1B.setGeometry(QtCore.QRect(410, 109, 81, 20))
        self.tipotramite1B.setObjectName("tipotramite1B")
       
        self.tipotramite1C = QtWidgets.QComboBox(self.centralWidget)
        self.tipotramite1C.setGeometry(QtCore.QRect(497, 109, 81, 20))    
        self.tipotramite1C.setObjectName("tipotramite1C")
                       
    
    def setupUi(self, ItramAltasBeta):
        ItramAltasBeta.setObjectName("ItramAltasBeta")
        ItramAltasBeta.resize(618, 428)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 0, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Link, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 0, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Link, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 0, 127))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Link, brush)
        ItramAltasBeta.setPalette(palette)
        self.centralWidget = QtWidgets.QWidget(ItramAltasBeta)
        self.centralWidget.setObjectName("centralWidget")
        self.datalabel = QtWidgets.QLabel(self.centralWidget)
        self.datalabel.setGeometry(QtCore.QRect(0, 0, 191, 51))

        self.datalabel.setObjectName("datalabel")
        self.groupBox = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox.setGeometry(QtCore.QRect(20, 74, 153, 261))
        self.groupBox.setObjectName("groupBox")
        self.line_appat = QtWidgets.QLineEdit(self.groupBox)
        self.line_appat.setGeometry(QtCore.QRect(10, 42, 133, 20))
        self.line_appat.setObjectName("line_appat")
        self.line_apmat = QtWidgets.QLineEdit(self.groupBox)
        self.line_apmat.setGeometry(QtCore.QRect(10, 87, 133, 20))
        self.line_apmat.setObjectName("line_apmat")
        self.line_nombre = QtWidgets.QLineEdit(self.groupBox)
        self.line_nombre.setGeometry(QtCore.QRect(10, 132, 133, 20))
        self.line_nombre.setObjectName("line_nombre")
        self.line_tel = QtWidgets.QLineEdit(self.groupBox)
        self.line_tel.setGeometry(QtCore.QRect(10, 177, 133, 20))
        self.line_tel.setObjectName("line_tel")
        self.line_email = QtWidgets.QLineEdit(self.groupBox)
        self.line_email.setGeometry(QtCore.QRect(10, 222, 133, 20))
        self.line_email.setObjectName("line_email")
        self.appatCliente = QtWidgets.QLabel(self.groupBox)
        self.appatCliente.setGeometry(QtCore.QRect(10, 23, 91, 16))
        self.appatCliente.setObjectName("appatCliente")
        self.apmatCliente = QtWidgets.QLabel(self.groupBox)
        self.apmatCliente.setGeometry(QtCore.QRect(10, 68, 91, 16))
        self.apmatCliente.setObjectName("apmatCliente")
        self.nombreCliente = QtWidgets.QLabel(self.groupBox)
        self.nombreCliente.setGeometry(QtCore.QRect(10, 113, 51, 16))
        self.nombreCliente.setObjectName("nombreCliente")
        self.label_4 = QtWidgets.QLabel(self.groupBox)
        self.label_4.setGeometry(QtCore.QRect(10, 158, 51, 16))
        self.label_4.setObjectName("label_4")
        self.e_mail = QtWidgets.QLabel(self.groupBox)
        self.e_mail.setGeometry(QtCore.QRect(10, 203, 47, 16))
        self.e_mail.setObjectName("e_mail")
        self.line = QtWidgets.QFrame(self.centralWidget)
        self.line.setGeometry(QtCore.QRect(347, 52, 141, 20))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label_6 = QtWidgets.QLabel(self.centralWidget)
        self.label_6.setGeometry(QtCore.QRect(346, 34, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(self.centralWidget)
        self.label_7.setGeometry(QtCore.QRect(392, 33, 91, 19))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_7.setFont(font)
        self.label_7.setObjectName("label_7")
        self.Quantity = QtWidgets.QSpinBox(self.centralWidget)
        self.Quantity.setGeometry(QtCore.QRect(215, 110, 30, 20))
        self.Quantity.setObjectName("Quantity")
        self.moreTramits = QtWidgets.QPushButton(self.centralWidget)
        self.moreTramits.setGeometry(QtCore.QRect(191, 109, 20, 21))
        self.moreTramits.setObjectName("moreTramits")
        
        ######################### Button Event Agregar tramite ##############################3
        self.moreTramits.clicked.connect(self.AgregaTramite_1)



        self.tipotramite1A = QtWidgets.QComboBox(self.centralWidget)
        self.tipotramite1A.setGeometry(QtCore.QRect(250, 108, 131, 22))
        self.tipotramite1A.setObjectName("tipotramite1A")
        self.tipotramite1A.addItems('Visa Visa_Canada Pasaporte_Mexicano Pasaporte_Americano Apostille Traduccion SSN'.split())
        self.moreoptions1 = QtWidgets.QToolButton(self.centralWidget)
        self.moreoptions1.setGeometry(QtCore.QRect(387, 109, 16, 25))
        self.moreoptions1.setObjectName("moreoptions1")
        ######################### Button Event Agregar opcion1 ##############################3
        self.moreoptions1.clicked.connect(self.AgregaOpcion1)

        self.tipotramite1B = QtWidgets.QComboBox(self.centralWidget)

 

        self.label = QtWidgets.QLabel(self.centralWidget)
        self.label.setGeometry(QtCore.QRect(220, 88, 16, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralWidget)
        self.label_2.setGeometry(QtCore.QRect(251, 90, 81, 16))
        self.label_2.setObjectName("label_2")
        self.moreTramits_2 = QtWidgets.QPushButton(self.centralWidget)

        self.moreTramits_2.setObjectName("moreTramits_2")
        self.Quantity_2 = QtWidgets.QSpinBox(self.centralWidget)

        self.Quantity_2.setObjectName("Quantity_2")
  #      self.tipotramite1C_2 = QtWidgets.QComboBox(self.centralWidget)




#        self.tipotramite1B_2 = QtWidgets.QComboBox(self.centralWidget)





        self.pushButton = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton.setGeometry(QtCore.QRect(230, 340, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton_2.setGeometry(QtCore.QRect(311, 340, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        ItramAltasBeta.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(ItramAltasBeta)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 618, 21))
        self.menuBar.setObjectName("menuBar")
        ItramAltasBeta.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(ItramAltasBeta)
        self.mainToolBar.setObjectName("mainToolBar")
        ItramAltasBeta.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(ItramAltasBeta)
        self.statusBar.setObjectName("statusBar")
        ItramAltasBeta.setStatusBar(self.statusBar)

        self.retranslateUi(ItramAltasBeta)
        QtCore.QMetaObject.connectSlotsByName(ItramAltasBeta)

    def retranslateUi(self, ItramAltasBeta):
        ItramAltasBeta.setWindowTitle( "ItramAltasBeta")
        self.datalabel.setText( "TextLabel")
        self.groupBox.setTitle( "*Datos del Cliente")
        self.appatCliente.setText( "Apellido Paterno")
        self.apmatCliente.setText( "Apellido Materno")
        self.nombreCliente.setText( "Nombre")
        self.label_4.setText( "Teléfono")
        self.e_mail.setText( "e-mail")
        self.label_6.setText( "FOLIO")
        self.label_7.setText( "numero folio")
        self.moreTramits.setText( "+")
        self.moreoptions1.setText( "opciones")
        self.label.setText( "Q.")
        self.label_2.setText( "Tipo de trámite")
#        self.moreTramits_2.setText( "+")
#        self.moreoptions1_2.setText( "...")
        self.pushButton.setText( "Save")
        self.pushButton_2.setText( "Cancel")


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ItramAltasBeta = QtWidgets.QMainWindow()
    ui = Ui_ItramAltasBeta()
    ui.setupUi(ItramAltasBeta)
    ItramAltasBeta.show()
    sys.exit(app.exec_())

