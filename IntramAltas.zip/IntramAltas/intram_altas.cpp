#include "intram_altas.h"
#include "ui_intram_altas.h"
#include "QDateTime.h"
#include  <QPixmap>

Intram_Altas::Intram_Altas(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Intram_Altas)
{
    ui->setupUi(this);


    ui->in_itemtype->addItem("Apostille");
    ui->in_itemtype->addItem("Traduccion");
    ui->in_itemtype->addItem("Visa");
    ui->in_itemtype->addItem("Pasaporte");
    ui->in_itemtype->addItem("Actas");

    ui->in_currency->addItem("MX");
    ui->in_currency->addItem("DLLS");


    QDateTime Date=QDateTime::currentDateTime();
    QString Datetext=Date.toString();
    ui->Date->setText(Datetext);
}

Intram_Altas::~Intram_Altas()
{
    delete ui;
}
