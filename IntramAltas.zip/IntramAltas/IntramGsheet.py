import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope =['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']

credentials = ServiceAccountCredentials.from_json_keyfile_name('PySheets-e4d635189daa.json',scope)

gc= gspread.authorize(credentials)

wks = gc.open('py_control').sheet1

#print(wks.get_all_records())

#wks.delete_row(2)

wks.append_row(['casi', 'a manejar'])
#wks.append_row(['dia', 'lluvioso'])
