#ifndef INTRAM_ALTAS_H
#define INTRAM_ALTAS_H

#include <QMainWindow>

namespace Ui {
class Intram_Altas;
}

class Intram_Altas : public QMainWindow
{
    Q_OBJECT

public:
    explicit Intram_Altas(QWidget *parent = 0);
    ~Intram_Altas();

private:
    Ui::Intram_Altas *ui;
};

#endif // INTRAM_ALTAS_H
