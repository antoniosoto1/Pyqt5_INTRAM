# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'intram_altas.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QDate, QTime, QDateTime, Qt
from PyQt5.QtWidgets import (QLabel, QRadioButton, QPushButton, QVBoxLayout, QApplication, QWidget)

import gspread
import datetime

from oauth2client.service_account import ServiceAccountCredentials

scope =['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
credentials = ServiceAccountCredentials.from_json_keyfile_name('PySheets-e4d635189daa.json',scope)
gc= gspread.authorize(credentials)
wks = gc.open('py_control').sheet1

now = QDate.currentDate()
now =QDateTime.currentDateTime()

class Ui_Intram_Altas(object):

    def Save_AltaData(self):
        now =QDateTime.currentDateTime()
        alt2gs_apellidopat = self.in_apellido_pat.text()
        alt2gs_apellidomat = self.in_apellido_mat.text()
        alt2gs_nombre   =   self.in_nombre.text()
        alt2gs_ttramite =   self.in_itemtype.currentText()
        alt2gs_dateTime =   (now.toString(Qt.DefaultLocaleLongDate))
        alt2gs_comments =   self.in_comments.toPlainText()


        self.btn_clk(self.in_cashmodey.isChecked(), self.label_9)

        Galt2gs_paytype =   self.label_9.text()

        wks.append_row([alt2gs_apellidopat, alt2gs_apellidomat, alt2gs_nombre,
                        alt2gs_ttramite,alt2gs_dateTime,alt2gs_comments,Galt2gs_paytype])

    def btn_clk(self, chk,label_9):
        if chk:
            label_9.setText('Efectivo')
        else:
            label_9.setText('Deposito')

    def setupUi(self, Intram_Altas):

        Intram_Altas.setObjectName("Intram_Altas")
        Intram_Altas.resize(508, 568)
        
        self.centralWidget = QtWidgets.QWidget(Intram_Altas)
        self.centralWidget.setObjectName("centralWidget")
        self.in_itemtype = QtWidgets.QComboBox(self.centralWidget)
        self.in_itemtype.setGeometry(QtCore.QRect(310, 160, 111, 20))
        self.in_itemtype.setObjectName("in_itemtype")
        self.in_itemtype.addItem("Visa")
        self.in_itemtype.addItem("Visa Canada")
        self.in_itemtype.addItem("Pasaporte Mexicano")
        self.in_itemtype.addItem("Pasaporte Americano")
        self.in_itemtype.addItem("Apostille")
        self.in_itemtype.addItem("Traduccion")
        self.in_itemtype.addItem("SSN")                
        self.groupBox = QtWidgets.QGroupBox(self.centralWidget)
        self.groupBox.setGeometry(QtCore.QRect(40, 120, 221, 271))
        self.groupBox.setObjectName("groupBox")
        self.in_apellido_pat = QtWidgets.QLineEdit(self.groupBox)
        self.in_apellido_pat.setGeometry(QtCore.QRect(31, 40, 133, 20))
        self.in_apellido_pat.setObjectName("in_apellido_pat")
        self.in_apellido_mat = QtWidgets.QLineEdit(self.groupBox)
        self.in_apellido_mat.setGeometry(QtCore.QRect(31, 85, 133, 20))
        self.in_apellido_mat.setObjectName("in_apellido_mat")
        self.in_nombre = QtWidgets.QLineEdit(self.groupBox)
        self.in_nombre.setGeometry(QtCore.QRect(31, 130, 133, 20))
        self.in_nombre.setObjectName("in_nombre")
        self.label = QtWidgets.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(31, 21, 101, 16))
        self.label.setObjectName("label")
        self.label_3 = QtWidgets.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(31, 66, 101, 16))
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.groupBox)
        self.label_4.setGeometry(QtCore.QRect(31, 111, 51, 16))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.groupBox)
        self.label_5.setGeometry(QtCore.QRect(30, 160, 47, 13))
        self.label_5.setObjectName("label_5")
        self.in_email = QtWidgets.QLineEdit(self.groupBox)
        self.in_email.setGeometry(QtCore.QRect(30, 180, 131, 20))
        self.in_email.setObjectName("in_email")
        self.label_11 = QtWidgets.QLabel(self.groupBox)
        self.label_11.setGeometry(QtCore.QRect(31, 211, 16, 16))
        self.label_11.setObjectName("label_11")
        self.in_telephone = QtWidgets.QLineEdit(self.groupBox)
        self.in_telephone.setGeometry(QtCore.QRect(31, 230, 133, 20))
        self.in_telephone.setObjectName("in_telephone")
        self.in_comments = QtWidgets.QTextEdit(self.centralWidget)
        self.in_comments.setGeometry(QtCore.QRect(310, 240, 151, 61))
        self.in_comments.setObjectName("in_comments")
        
        self.Date = QtWidgets.QLabel(self.centralWidget)
        self.Date.setGeometry(QtCore.QRect(50, 20, 281, 51))
        font = QtGui.QFont()
        font.setFamily("Perpetua")
        font.setPointSize(14)
        self.Date.setFont(font)
        self.Date.setObjectName("Date")

        self.label_8 = QtWidgets.QLabel(self.centralWidget)
        self.label_8.setGeometry(QtCore.QRect(310, 141, 74, 16))
        self.label_8.setObjectName("label_8")
        self.label_6 = QtWidgets.QLabel(self.centralWidget)
        self.label_6.setGeometry(QtCore.QRect(310, 220, 131, 16))
        self.label_6.setObjectName("label_6")
        self.label_9 = QtWidgets.QLabel(self.centralWidget)
        self.label_9.setGeometry(QtCore.QRect(321, 313, 38, 16))
        self.label_9.setObjectName("label_9")
        self.in_firstpayment = QtWidgets.QLineEdit(self.centralWidget)
        self.in_firstpayment.setGeometry(QtCore.QRect(321, 332, 61, 20))
        self.in_firstpayment.setText("")
        self.in_firstpayment.setObjectName("in_firstpayment")
        self.in_currency = QtWidgets.QComboBox(self.centralWidget)
        self.in_currency.setGeometry(QtCore.QRect(385, 330, 51, 22))
        self.in_currency.setObjectName("in_currency")
        self.in_currency.addItem("MXN")
        self.in_currency.addItem("DLLS")
        self.label_10 = QtWidgets.QLabel(self.centralWidget)
        self.label_10.setGeometry(QtCore.QRect(310, 330, 16, 20))
        self.label_10.setObjectName("label_10")
        self.line = QtWidgets.QFrame(self.centralWidget)
        self.line.setGeometry(QtCore.QRect(300, 130, 118, 3))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.in_cashmodey = QtWidgets.QRadioButton(self.centralWidget)
        self.in_cashmodey.setGeometry(QtCore.QRect(310, 380, 82, 17))
        self.in_cashmodey.setObjectName("in_cashmodey")
        self.in_deposity = QtWidgets.QRadioButton(self.centralWidget)
        self.in_deposity.setGeometry(QtCore.QRect(310, 410, 111, 17))
        self.in_deposity.setObjectName("in_deposity")
        self.label_7 = QtWidgets.QLabel(self.centralWidget)
        self.label_7.setGeometry(QtCore.QRect(71, 401, 133, 16))
        self.label_7.setObjectName("label_7")
        self.firstvisitn = QtWidgets.QRadioButton(self.centralWidget)
        self.firstvisitn.setGeometry(QtCore.QRect(109, 421, 36, 17))
        self.firstvisitn.setObjectName("firstvisitn")
        self.firstvisity = QtWidgets.QRadioButton(self.centralWidget)
        self.firstvisity.setGeometry(QtCore.QRect(72, 421, 31, 17))
        self.firstvisity.setObjectName("firstvisity")
        self.label_2 = QtWidgets.QLabel(self.centralWidget)
        self.label_2.setGeometry(QtCore.QRect(311, 61, 33, 16))
        self.label_2.setObjectName("label_2")
        self.label_1 = QtWidgets.QLabel(self.centralWidget)
        self.label_1.setGeometry(QtCore.QRect(350, 57, 64, 23))
        self.label_1.setObjectName("label_1")
        self.label_1.setFont(font)


        self.Save_btn = QtWidgets.QPushButton(self.centralWidget)
        self.Save_btn.setGeometry(QtCore.QRect(171, 462, 75, 23))
        self.Save_btn.setObjectName("Save_btn")

        ######################### Button Event ##############################3
        self.Save_btn.clicked.connect(self.Save_AltaData)

        self.Cancel_btn = QtWidgets.QPushButton(self.centralWidget)
        self.Cancel_btn.setGeometry(QtCore.QRect(252, 462, 75, 23))
        self.Cancel_btn.setObjectName("Cancel_btn")

        Intram_Altas.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(Intram_Altas)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 508, 21))
        self.menuBar.setObjectName("menuBar")
        Intram_Altas.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(Intram_Altas)
        self.mainToolBar.setObjectName("mainToolBar")
        Intram_Altas.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(Intram_Altas)
        self.statusBar.setObjectName("statusBar")
        Intram_Altas.setStatusBar(self.statusBar)

        self.retranslateUi(Intram_Altas)
        QtCore.QMetaObject.connectSlotsByName(Intram_Altas)

    def retranslateUi(self, Intram_Altas):
        _translate = QtCore.QCoreApplication.translate
        Intram_Altas.setWindowTitle("Intram Altas")
        self.groupBox.setTitle(_translate("Intram_Altas", "*Datos del Cliente"))
        self.label.setText("Apellido Paterno")
        self.label_3.setText(_translate("Intram_Altas", "<html><head/><body><p><span style=\" font-size:10pt;\">Apellido Materno</span></p></body></html>"))
        self.label_4.setText(_translate("Intram_Altas", "<html><head/><body><p><span style=\" font-size:10pt;\">Nombre</span></p></body></html>"))
        self.label_5.setText(_translate("Intram_Altas", "<html><head/><body><p><span style=\" font-size:10pt;\">e-mail</span></p></body></html>"))
        self.label_11.setText(_translate("Intram_Altas", "Tel"))
        self.Date.setText(now.toString())
        self.label_8.setText(_translate("Intram_Altas", "Tipo de Tràmite"))
        self.label_6.setText(_translate("Intram_Altas", "Documentos que entrega"))
        self.label_9.setText(_translate("Intram_Altas", "Anticipo"))
        self.label_10.setText(_translate("Intram_Altas", "$"))
        self.in_cashmodey.setText(_translate("Intram_Altas", "Efectivo"))
        self.in_deposity.setText(_translate("Intram_Altas", "Deposito Bancario"))
        self.label_7.setText(_translate("Intram_Altas", "¿Primera vez que nos Vista?"))
        self.firstvisitn.setText(_translate("Intram_Altas", "No"))
        self.firstvisity.setText(_translate("Intram_Altas", "Si"))
        self.label_2.setText(_translate("Intram_Altas", "<html><head/><body><p><span style=\" font-weight:600;\">FOLIO</span></p></body></html>"))
        self.Save_btn.setText(_translate("Intram_Altas", "Save"))
        self.Cancel_btn.setText(_translate("Intram_Altas", "Cancel"))
        self.label_1.setText(_translate("Intram_Altas","101" ))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Intram_Altas = QtWidgets.QMainWindow()
    ui = Ui_Intram_Altas()
    ui.setupUi(Intram_Altas)
    Intram_Altas.show()
    sys.exit(app.exec_())

