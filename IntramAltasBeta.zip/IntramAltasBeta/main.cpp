#include "itramaltasbeta.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ItramAltasBeta w;
    w.show();

    return a.exec();
}
