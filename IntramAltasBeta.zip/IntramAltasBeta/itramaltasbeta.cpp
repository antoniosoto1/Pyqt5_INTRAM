#include "itramaltasbeta.h"
#include "ui_itramaltasbeta.h"

ItramAltasBeta::ItramAltasBeta(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ItramAltasBeta)
{
    ui->setupUi(this);
}

ItramAltasBeta::~ItramAltasBeta()
{
    delete ui;
}
